<?php
define('S_ROOT', dirname(__FILE__).DIRECTORY_SEPARATOR);

//product
define('PRODUCT_SCOPE_PUBLIC', 1);
define('PRODUCT_SCOPE_PRIVATE', 2);

define('PRODUCT_API_RUL', '');
